# CRUMBLE! — what to type for each product and pass

Images are in this folder (`store/products/`), 512×512 PNG, all in the same gold-coin badge style with a big label (X1, X5, X12, 500, 2,500, 2X, SKIP, X2, AUTO, FAST, VIP). The corners are see-through, so they look right as circles (passes) and squares (products). `preview_all.png` shows them all. To change a label, edit `make_passes_medal.py` and run it again.
After creating each one, **copy its ID** and send it to me (or paste it into `src/shared/Config.luau`, replacing `Id = 0` on the matching line).

---

## Part 1 — Game settings (12 players + R15)

### 12 players per server
1. Go to **create.roblox.com** → **Creations** → click **CRUMBLE!**
2. Left menu: **Places** → click the place (the one with the star, the start place).
3. Left menu: **Access**.
4. **Maximum Visitor Count** (server size) → type **12** → **Save Changes**.

(Studio way: Home → **Game Settings** → **Places** → ⋯ next to the place → Configure / **Max Players = 12** → Save. The game must be published first.)
Studio test windows may still show a different number; live servers use 12.

### R15 avatars (the game needs R15: the weapon poses are made for R15 bodies)
1. Open the published game in **Roblox Studio**.
2. Top bar **Avatar** tab (or **File** menu) → **Avatar Settings**.
3. In the window's top bar click the **⋯** (three dots) → choose **R15** (not "R15 & R6").
4. **Save Changes** → if it asks, **Save and Restart**.
5. Publish (File → Publish to Roblox), then Play: your character should have elbows and knees.

If the Avatar Settings window is stuck off-screen: **Window → Reset Layout**, then open it again.

---

## Part 2 — Developer Products (can be bought again and again)
Creator Dashboard → CRUMBLE! → **Monetization → Developer Products → Create a Developer Product**. Upload the image, type the name, description and price, then **Create**. Copy the **Product ID**.

| # | Name (type exactly) | Price | Image | Config key |
|---|---|---|---|---|
| 1 | 1 Spin | 49 | product_spin1.png | Spin1 |
| 2 | 5 Spins | 199 | product_spin5.png | Spin5 |
| 3 | 12 Spins | 449 | product_spin12.png | Spin12 |
| 4 | 500 Coins | 25 | product_coins500.png | Coins500 |
| 5 | 2,500 Coins | 99 | product_coins2500.png | Coins2500 |
| 6 | 2x Coins (30 min) | 49 | product_boost2x.png | Boost2x |
| 7 | Skip Timer | 25 | product_skiptimer.png | SkipTimer |

**Descriptions (copy-paste):**

**1 Spin**
> 1 spin in the Vault for a random weapon. Odds: Common 55%, Uncommon 26%, Rare 12%, Epic 5%, Legendary 1.6%, Mythic 0.4%. Pity counts: Epic or better is guaranteed within 20 spins.

**5 Spins**
> 5 spins in the Vault for random weapons. Duplicates merge in the Forge to level your weapons up. Odds: Common 55%, Uncommon 26%, Rare 12%, Epic 5%, Legendary 1.6%, Mythic 0.4%. Pity counts too.

**12 Spins**
> The best value: 12 spins in the Vault for random weapons. Odds: Common 55%, Uncommon 26%, Rare 12%, Epic 5%, Legendary 1.6%, Mythic 0.4%. Pity: Epic+ within 20 spins, Legendary+ within 60, Mythic within 200.

**500 Coins**
> 500 coins for merging weapons in the Forge and for coin spins.

**2,500 Coins**
> 2,500 coins: enough for 2 coin spins or a bunch of Forge merges.

**2x Coins (30 min)**
> Double coins from every round for 30 minutes. The coin limit per round doubles too. Buying again adds 30 more minutes.

**Skip Timer**
> Your hourly coin spin is ready right now. The spin still costs coins. Up to 3 times a day.

---

## Part 3 — Game Passes (bought once, kept forever)
Creator Dashboard → CRUMBLE! → **Monetization → Passes → Create a Pass**. Upload the image, type the name and description, **Create Pass**. Then open the pass → **Sales** → switch **Item for Sale ON** → type the price → **Save**. Copy the **Pass ID** (in the URL or the ⋯ menu → Copy Asset ID).

| # | Name (type exactly) | Price | Image | Config key |
|---|---|---|---|---|
| 1 | Auto Merge | 199 | pass_automerge.png | AutoMerge |
| 2 | Fast Coin Spins | 149 | pass_fastcoinspins.png | FastSpins |
| 3 | 2x Coins Forever | 299 | pass_2xcoins.png | Coins2x |
| 4 | VIP | 149 | pass_vip.png | VIP |

**Descriptions (copy-paste):**

**Auto Merge**
> Never merge by hand again! Adds a MERGE EVERYTHING button to the Forge, and new weapon copies merge by themselves after every spin. Uses your copies and coins as normal (never your wildcards). You can switch auto-merge off any time.

**Fast Coin Spins**
> Your coin spin is ready every 30 minutes instead of every hour. Forever.

**2x Coins Forever**
> Double coins from every round, forever. The coin limit per round doubles too. With a 30-minute 2x boost on top, you get 3x!

**VIP**
> Stand out in every match: a gold VIP tag over your head and a gold [VIP] in front of your name in chat. Looks only, no extra power.

---

## Part 4 — Send me the IDs
Copy this, fill it in, and send it back:

```
Spin1 =
Spin5 =
Spin12 =
Coins500 =
Coins2500 =
Boost2x =
SkipTimer =
AutoMerge =
FastSpins =
Coins2x =
VIP =
```
I'll put them in the game and rebuild it. Then you open the new file and publish over the same game.
